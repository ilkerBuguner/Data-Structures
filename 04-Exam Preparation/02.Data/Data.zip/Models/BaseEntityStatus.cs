﻿namespace _02.Data.Models
{
    public enum BaseEntityStatus
    {
        InStore,
        Reserved,
        PendingFunds,
        Payed,
        Sold
    }
}
